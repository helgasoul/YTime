/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // If you have a custom output directory, specify it here, e.g.:
  // distDir: 'build',
  // Ensure environment variables for basic auth are available during build if needed
  // (though middleware runs at the edge, not during build for these vars)
  env: {
    BASIC_AUTH_USER: process.env.BASIC_AUTH_USER,
    BASIC_AUTH_PASSWORD: process.env.BASIC_AUTH_PASSWORD,
  }
};

module.exports = nextConfig;

