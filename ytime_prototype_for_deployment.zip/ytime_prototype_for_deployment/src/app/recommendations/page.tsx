const recommendationsData = {
  nutrition: [
    "Добавьте в рацион больше зеленых листовых овощей.",
    "Сократите потребление обработанных продуктов и сахара.",
    "Убедитесь, что получаете достаточное количество клетчатки (25-30г в день)."
  ],
  activity: [
    "Рекомендуется не менее 150 минут умеренной аэробной активности в неделю.",
    "Попробуйте включить силовые тренировки 2 раза в неделю.",
    "Не забывайте про ежедневную растяжку или йогу для гибкости."
  ],
  checkups: [
    "Запланируйте ежегодный визит к гинекологу.",
    "Проверьте уровень витамина D и ферритина (по показаниям).",
    "Не пропускайте плановую маммографию (согласно возрасту и рекомендациям врача)."
  ],
  sleep: [
    "Старайтесь спать 7-9 часов каждую ночь.",
    "Создайте расслабляющую рутину перед сном.",
    "Ограничьте использование гаджетов за час до сна."
  ]
};

export default function RecommendationsPage() {
  return (
    <div className="min-h-screen bg-brand-background">
      {/* Reusable Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <a href="/dashboard/" className="flex items-center space-x-2">
                <img src="/assets/logo.png" alt="YTime Logo" width={40} height={40} />
                {/* <span className="text-2xl font-bold text-brand-primary">YTime</span> */}
              </a>
            </div>
            <nav className="hidden md:flex space-x-1">
              <a href="/dashboard/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Главная</a>
              <a href="/lifecycles/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Жизненные Циклы</a>
              <a href="/risks/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Мои Риски</a>
              <a href="/map-services/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Карта Сервисов</a>
              <a href="/education/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Образование</a>
              <a href="/mental-wellness/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Ментальное Благополучие</a>
              <a href="/community/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Сообщество</a>
            </nav>
            <div className="flex items-center">
              <span className="text-sm text-brand-text-primary mr-4">Профиль</span>
              <a href="/" className="text-sm text-brand-secondary hover:text-brand-accent">Выйти</a>
            </div>
          </div>
        </div>
      </header>

      <main className="py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-semibold text-brand-text-primary mb-8">Ваши Персональные Рекомендации</h1>
          
          <div className="space-y-8">
            <RecommendationSection title="Питание" recommendations={recommendationsData.nutrition} icon="🥗" />
            <RecommendationSection title="Физическая Активность" recommendations={recommendationsData.activity} icon="🏃‍♀️" />
            <RecommendationSection title="Медицинские Осмотры (Чек-апы)" recommendations={recommendationsData.checkups} icon="🩺" />
            <RecommendationSection title="Сон и Отдых" recommendations={recommendationsData.sleep} icon="😴" />
          </div>

          <div className="mt-10 text-sm text-brand-text-secondary bg-blue-50 p-4 rounded-md border border-blue-200">
            <p><strong>Важно:</strong> Эти рекомендации носят общий характер и основаны на предоставленной вами информации. Они не заменяют консультацию с врачом. Пожалуйста, обсудите любые изменения в вашем образе жизни или плане лечения с вашим лечащим врачом.</p>
          </div>
        </div>
      </main>

      <footer className="bg-white border-t border-gray-200 mt-10">
        <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 text-center text-sm text-brand-text-secondary">
          <p>&copy; {new Date().getFullYear()} YTime. Все права защищены.</p>
           <p className="mt-1">
            <a href="/terms/" className="hover:text-brand-secondary">Условия использования</a> | <a href="/privacy/" className="hover:text-brand-secondary">Политика конфиденциальности</a>
          </p>
        </div>
      </footer>
    </div>
  );
}

const RecommendationSection = ({ title, recommendations, icon }: { title: string, recommendations: string[], icon: string }) => (
  <div className="bg-white p-6 rounded-lg shadow-md">
    <div className="flex items-center mb-4">
      <span className="text-3xl mr-3">{icon}</span>
      <h2 className="text-xl font-semibold text-brand-secondary">{title}</h2>
    </div>
    <ul className="list-disc list-inside space-y-2 text-sm text-brand-text-secondary">
      {recommendations.map((rec, index) => (
        <li key={index}>{rec}</li>
      ))}
    </ul>
    <a href="/education/" className="text-sm text-brand-primary hover:underline mt-4 inline-block">Узнать больше по этой теме</a>
  </div>
);

