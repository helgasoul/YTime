import "./globals.css";
import { Link } from "react-router-dom"; // Assuming react-router-dom is used for routing

// For a Vite/React app, metadata (title, description) is typically handled in public/index.html
// or with a library like React Helmet. We will remove Next.js specific metadata here.

// Fonts like Inter are typically linked in public/index.html or imported in a global CSS file.
// We will remove Next.js specific font handling here.

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru">
      {/* <head> can be managed in public/index.html or with React Helmet */}
      <body className={`bg-ytime-brand_background text-ytime-brand_text_dark`}>
        <header className="bg-white shadow-md sticky top-0 z-50">
          <nav className="container mx-auto px-4 sm:px-6 py-3 flex justify-between items-center">
            <Link to="/" className="flex items-center"> {/* Changed href to to for react-router-dom */}
              <img src="/logo.png" alt="YTime Logo" width={36} height={36} className="mr-2" /> {/* Changed Image to img */}
              <span className="font-bold text-xl text-ytime-brand_primary">YTime</span>
            </Link>
            <div className="space-x-2 sm:space-x-4">
              <Link to="/" className="text-sm sm:text-base text-ytime-brand_primary hover:text-ytime-brand_accent font-medium">Главная</Link>
              <Link to="/dashboard" className="text-sm sm:text-base text-ytime-brand_primary hover:text-ytime-brand_accent font-medium">Дашборд</Link>
              <Link to="/map-services" className="text-sm sm:text-base text-ytime-brand_primary hover:text-ytime-brand_accent font-medium">Карта</Link>
              {/* Add other important links, ensure they are responsive */}
            </div>
          </nav>
        </header>
        <main className="pt-4 pb-8">
          {children}
        </main>
        <footer className="text-center py-5 mt-auto text-sm text-gray-700 border-t border-gray-200 bg-white">
          <p>&copy; {new Date().getFullYear()} YTime. Все права защищены.</p>
          <p className="text-xs text-gray-500 mt-1">Прототип платформы для женщин</p>
        </footer>
      </body>
    </html>
  );
}

