// Mock data for widgets - in a real app, this would come from state or API
const dashboardData = {
  userName: "Елена",
  todayFocus: "Не забудьте внести симптомы за сегодня.",
  cycleStatus: "Фолликулярная фаза, 7 день",
  riskIndicator: "средний",
  recommendations: [
    "Добавьте в рацион больше зеленых овощей.",
    "Пройдите 10,000 шагов сегодня."
  ],
  mentalWellnessPrompt: "Пройти скрининг самочувствия",
  newKnowledge: "Новая статья: Как питание влияет на ваш цикл",
};

const WidgetCard = ({ title, children, linkTo }: { title: string; children: React.ReactNode; linkTo?: string }) => (
  <a href={linkTo || "#"} className="block p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200 ease-in-out">
    <h3 className="text-lg font-semibold text-brand-secondary mb-2">{title}</h3>
    <div className="text-sm text-brand-text-secondary space-y-1">
      {children}
    </div>
  </a>
);

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-brand-background">
      {/* Header */} 
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <a href="/dashboard/" className="flex items-center space-x-2">
                <img src="/assets/logo.png" alt="YTime Logo" width={40} height={40} />
                {/* <span className="text-2xl font-bold text-brand-primary">YTime</span> */}
              </a>
            </div>
            <nav className="hidden md:flex space-x-1">
              <a href="/dashboard/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Главная</a>
              <a href="/lifecycles/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Жизненные Циклы</a>
              <a href="/risks/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Мои Риски</a>
              <a href="/map-services/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Карта Сервисов</a>
              <a href="/education/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Образование</a>
              <a href="/mental-wellness/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Ментальное Благополучие</a>
              <a href="/community/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Сообщество</a>
            </nav>
            <div className="flex items-center">
              <span className="text-sm text-brand-text-primary mr-4">Профиль</span>
              <a href="/" className="text-sm text-brand-secondary hover:text-brand-accent">Выйти</a>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */} 
      <main className="py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-semibold text-brand-text-primary mb-2">Здравствуйте, {dashboardData.userName}!</h1>
          <p className="text-md text-brand-accent mb-8">{dashboardData.todayFocus}</p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <WidgetCard title="Мой Цикл" linkTo="/lifecycles/menstrual/">
              <p>{dashboardData.cycleStatus}</p>
              <p className="mt-2 text-brand-primary hover:underline">Перейти к календарю</p>
            </WidgetCard>

            <WidgetCard title="Карта Рисков" linkTo="/risks/">
              <p>Общий индикатор: <span className="font-semibold text-orange-500">{dashboardData.riskIndicator}</span></p>
              <p className="mt-2 text-brand-primary hover:underline">Смотреть детали</p>
            </WidgetCard>

            <WidgetCard title="Рекомендации для Вас" linkTo="/recommendations/">
              {dashboardData.recommendations.map((rec, index) => (
                <p key={index}>- {rec}</p>
              ))}
              <p className="mt-2 text-brand-primary hover:underline">Все рекомендации</p>
            </WidgetCard>

            <WidgetCard title="Ментальное Благополучие" linkTo="/mental-wellness/">
              <p>{dashboardData.mentalWellnessPrompt}</p>
              <p className="mt-2 text-brand-primary hover:underline">Начать</p>
            </WidgetCard>

            <WidgetCard title="Новое в Библиотеке Знаний" linkTo="/education/">
              <p>{dashboardData.newKnowledge}</p>
              <p className="mt-2 text-brand-primary hover:underline">Читать</p>
            </WidgetCard>
            
            <WidgetCard title="Сообщество YTime" linkTo="/community/">
              <p>Общайтесь и получайте поддержку.</p>
              <p className="mt-2 text-brand-primary hover:underline">Присоединиться</p>
            </WidgetCard>
          </div>
        </div>
      </main>

      {/* Footer */} 
      <footer className="bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 text-center text-sm text-brand-text-secondary">
          <p>&copy; {new Date().getFullYear()} YTime. Все права защищены.</p>
          <p className="mt-1">
            <a href="/terms/" className="hover:text-brand-secondary">Условия использования</a> | <a href="/privacy/" className="hover:text-brand-secondary">Политика конфиденциальности</a>
          </p>
        </div>
      </footer>
    </div>
  );
}

