export default function QuestionnairePage() {
  return (
    <div className="min-h-screen bg-brand-background flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-lg p-8 space-y-6 bg-white rounded-lg shadow-xl">
        <div className="flex justify-center mb-4">
          <img src="/assets/logo.png" alt="YTime Logo" width={80} height={80} />
        </div>
        <h1 className="text-2xl font-bold text-center text-brand-primary">Расскажите немного о себе</h1>
        <p className="text-sm text-center text-brand-text-secondary">Шаг 1 из 3</p>
        
        <form className="space-y-6">
          <div>
            <label htmlFor="dob" className="block text-sm font-medium text-brand-text-primary">Дата рождения</label>
            <input 
              type="date" 
              name="dob" 
              id="dob" 
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-secondary focus:border-brand-secondary sm:text-sm" 
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-brand-text-primary">Основные цели использования платформы</label>
            <div className="mt-2 space-y-2">
              {[
                "Отслеживание цикла",
                "Подготовка к беременности",
                "Управление менопаузой",
                "Общее улучшение здоровья",
              ].map((goal) => (
                <div key={goal} className="flex items-center">
                  <input 
                    id={`goal-${goal}`}
                    name="goals" 
                    type="checkbox" 
                    className="h-4 w-4 text-brand-primary border-gray-300 rounded focus:ring-brand-secondary" 
                  />
                  <label htmlFor={`goal-${goal}`} className="ml-2 block text-sm text-brand-text-primary">{goal}</label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <label htmlFor="chronic_conditions" className="block text-sm font-medium text-brand-text-primary">Есть ли известные хронические заболевания?</label>
            <select 
              id="chronic_conditions" 
              name="chronic_conditions" 
              className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-brand-secondary focus:border-brand-secondary sm:text-sm rounded-md"
            >
              <option>Нет</option>
              <option>Да</option>
            </select>
            {/* Conditional input for details if 'Yes' could be added here */}
          </div>

          <div className="flex justify-between pt-4">
            <a href="/dashboard/" className="px-6 py-2 border border-brand-primary text-brand-primary rounded-md shadow-sm text-sm font-medium hover:bg-brand-primary hover:text-brand-primary-text-on-color focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-primary transition-colors">
              Пропустить
            </a>
            <a href="/dashboard/" className="px-6 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-brand-primary-text-on-color bg-brand-primary hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-primary transition-colors">
              Далее
            </a>
          </div>
        </form>
      </div>
    </div>
  );
}

