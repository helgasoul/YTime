import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, CalendarDays, HeartPulse, Map, MessageSquare, ShieldCheck, Users, BookOpen } from "lucide-react";

const featureCards = [
  { 
    title: "Персональный Дашборд", 
    description: "Отслеживайте свои циклы, симптомы и получайте персональные инсайты.", 
    icon: <BarChart className="w-8 h-8 text-ytime-brand_accent" />, 
    link: "/dashboard/", // Adjusted for potential static site structure
    bgColor: "bg-ytime-light_pink"
  },
  {
    title: "Интерактивная Карта Сервисов", 
    description: "Находите клиники, лаборатории, фитнес-центры и другие полезные места.", 
    icon: <Map className="w-8 h-8 text-ytime-brand_accent" />, 
    link: "/map-services/", // Adjusted
    bgColor: "bg-ytime-light_blue"
  },
  {
    title: "Управление Жизненными Циклами", 
    description: "Ведите календарь менструального цикла, беременности и менопаузы.", 
    icon: <CalendarDays className="w-8 h-8 text-ytime-brand_accent" />, 
    link: "/lifecycles/", // Adjusted
    bgColor: "bg-ytime-lavender_blue"
  },
  {
    title: "Оценка Рисков Здоровья", 
    description: "Пройдите опросники для оценки рисков различных заболеваний.", 
    icon: <ShieldCheck className="w-8 h-8 text-ytime-brand_accent" />, 
    link: "/risks/", // Adjusted
    bgColor: "bg-ytime-light_pink"
  },
  {
    title: "Рекомендации и Советы", 
    description: "Получайте персонализированные советы по здоровью и образу жизни.", 
    icon: <HeartPulse className="w-8 h-8 text-ytime-brand_accent" />, 
    link: "/recommendations/", // Adjusted
    bgColor: "bg-ytime-light_blue"
  },
  {
    title: "Образовательные Материалы", 
    description: "Читайте статьи и смотрите видео о женском здоровье от экспертов.", 
    icon: <BookOpen className="w-8 h-8 text-ytime-brand_accent" />, 
    link: "/education/", // Adjusted
    bgColor: "bg-ytime-lavender_blue"
  },
  {
    title: "Поддержка Ментального Здоровья", 
    description: "Ресурсы и инструменты для заботы о вашем эмоциональном благополучии.", 
    icon: <MessageSquare className="w-8 h-8 text-ytime-brand_accent" />, 
    link: "/mental-wellness/", // Adjusted
    bgColor: "bg-ytime-light_pink"
  },
  {
    title: "Сообщество YTime", 
    description: "Общайтесь, делитесь опытом и находите поддержку в нашем сообществе.", 
    icon: <Users className="w-8 h-8 text-ytime-brand_accent" />, 
    link: "/community/", // Adjusted
    bgColor: "bg-ytime-light_blue"
  },
];

export default function HomePage() {
  return (
    <div className="container mx-auto p-4 sm:p-6">
      <section className="text-center py-10 sm:py-16 bg-gradient-to-r from-ytime-light_pink via-ytime-brand_background to-ytime-light_blue rounded-xl shadow-lg">
        <h1 className="text-4xl sm:text-5xl font-bold text-ytime-brand_primary mb-4">
          Добро пожаловать в YTime!
        </h1>
        <p className="text-lg sm:text-xl text-ytime-brand_text_dark mb-8 max-w-2xl mx-auto">
          Ваш персональный помощник в мире женского здоровья. Мы здесь, чтобы поддержать вас на каждом этапе жизни.
        </p>
        <a href="/questionnaire/"> {/* Replaced Link with a */}
          <Button size="lg" className="bg-ytime-brand_accent hover:bg-ytime-magenta_pink text-white font-semibold py-3 px-8 rounded-lg text-lg shadow-md transition-transform transform hover:scale-105">
            Начать Персонализацию
          </Button>
        </a>
      </section>

      <section className="py-12 sm:py-16">
        <h2 className="text-3xl font-bold text-center text-ytime-brand_primary mb-10 sm:mb-12">
          Ключевые Возможности Платформы
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8">
          {featureCards.map((feature) => (
            <Card key={feature.title} className={`shadow-lg hover:shadow-xl transition-shadow duration-300 border-none ${feature.bgColor} flex flex-col`}>
              <CardHeader className="flex-shrink-0">
                <div className="flex items-center justify-center w-16 h-16 bg-white rounded-full mx-auto mb-4 shadow-md">
                  {feature.icon}
                </div>
                <CardTitle className="text-xl font-semibold text-center text-ytime-brand_primary">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent className="text-center text-ytime-brand_text_dark flex-grow">
                <p className="text-sm">{feature.description}</p>
              </CardContent>
              <div className="p-4 mt-auto flex-shrink-0">
                <a href={feature.link} className="block w-full"> {/* Replaced Link with a */}
                  <Button variant="outline" className="w-full border-ytime-brand_accent text-ytime-brand_accent hover:bg-ytime-brand_accent hover:text-white transition-colors duration-300">
                    Перейти
                  </Button>
                </a>
              </div>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}

