import { Link, useSearchParams } from "react-router-dom"; // Replaced next/link and added useSearchParams
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"; // Ensured CardFooter is imported
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
// import { Calendar } from "@/components/ui/calendar"; // Commented out as it was marked unused and is a placeholder
import { ArrowLeft, CalendarDays, Clock, User, CheckCircle } from "lucide-react";
// import { useState } from "react"; // Commented out as it was marked unused

// Mock data - in a real app, this would come from query params and API
const MOCK_BOOKING_INFO = {
  serviceName: "Консультация терапевта первичная",
  clinicName: "Клиника \"Здоровье Семьи\"",
  specialistName: "Сидорова Елена Васильевна",
  availableDates: ["2025-05-20", "2025-05-21", "2025-05-22"],
  availableTimes: {
    "2025-05-20": ["10:00", "10:30", "14:00", "14:30"],
    "2025-05-21": ["09:00", "09:30", "15:00"],
    "2025-05-22": ["11:00", "16:00", "16:30"],
  }
};

export default function BookingPage() {
  const [searchParams] = useSearchParams(); // Using useSearchParams hook
  const serviceName = searchParams.get("serviceName") || MOCK_BOOKING_INFO.serviceName;
  const clinicName = searchParams.get("clinicName") || MOCK_BOOKING_INFO.clinicName;
  const specialistName = searchParams.get("specialistName"); // Optional

  return (
    <div className="container mx-auto p-4">
      <header className="mb-6">
        {/* Assuming a way to get back to the correct service detail, adjust link as needed */}
        <Link to={clinicName ? `/map-services/service-detail?id=${MOCK_SERVICE_DETAIL.id}` : "/map-services"}> 
          <Button variant="outline" className="mb-4 border-ytime-brand_secondary text-ytime-brand_secondary hover:bg-ytime-light_blue hover:text-ytime-brand_primary">
            <ArrowLeft className="w-4 h-4 mr-2" /> Назад к описанию сервиса
          </Button>
        </Link>
        <h1 className="text-3xl sm:text-4xl font-bold text-center text-ytime-brand_primary">Запись на прием</h1>
        <p className="text-center text-ytime-brand_text_dark mt-2">
          Вы записываетесь на: <strong>{serviceName}</strong>
          {specialistName && <> к специалисту <strong>{specialistName}</strong></>}
          {" "}в <strong>{clinicName}</strong>.
        </p>
      </header>

      <Card className="max-w-2xl mx-auto shadow-xl bg-white border-ytime-brand_background">
        <CardHeader>
          <CardTitle className="text-ytime-brand_primary">Выберите дату и время</CardTitle>
          <CardDescription className="text-ytime-brand_text_dark">Пожалуйста, выберите удобную для вас дату и время для визита.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
            <div>
              <Label htmlFor="booking-date-select" className="text-ytime-brand_text_dark font-medium flex items-center mb-2">
                <CalendarDays className="w-5 h-5 mr-2 text-ytime-brand_accent" /> Дата визита
              </Label>
              {/* Placeholder for actual calendar component integration */}
              <div className="p-3 border border-ytime-brand_secondary rounded-md bg-ytime-light_pink mb-2">
                <p className="text-sm text-ytime-brand_text_dark">Календарь будет здесь.</p>
                <p className="text-xs text-gray-500">Для прототипа, выберите дату из списка ниже.</p>
              </div>
              <Select>
                <SelectTrigger id="booking-date-select" className="mt-1 border-ytime-brand_secondary focus:border-ytime-brand_primary focus:ring-ytime-brand_primary">
                  <SelectValue placeholder="Выберите дату" />
                </SelectTrigger>
                <SelectContent>
                  {MOCK_BOOKING_INFO.availableDates.map(date => (
                    <SelectItem key={date} value={date}>{new Date(date).toLocaleDateString("ru-RU", { year: "numeric", month: "long", day: "numeric" })}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="booking-time" className="text-ytime-brand_text_dark font-medium flex items-center mb-2">
                <Clock className="w-5 h-5 mr-2 text-ytime-brand_accent" /> Время визита
              </Label>
              <Select>
                <SelectTrigger id="booking-time" className="border-ytime-brand_secondary focus:border-ytime-brand_primary focus:ring-ytime-brand_primary">
                  <SelectValue placeholder="Выберите время" />
                </SelectTrigger>
                <SelectContent>
                  {/* Assuming a date is selected, show times for it. For proto, show all. */}
                  {MOCK_BOOKING_INFO.availableTimes["2025-05-20"].map(time => (
                    <SelectItem key={time} value={time}>{time}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="border-t border-ytime-brand_background pt-6 space-y-4">
            <h3 className="text-lg font-semibold text-ytime-brand_primary flex items-center">
              <User className="w-5 h-5 mr-2 text-ytime-brand_accent" /> Ваши контактные данные
            </h3>
            <div>
              <Label htmlFor="fullName" className="text-sm font-medium text-ytime-brand_text_dark">ФИО</Label>
              <Input id="fullName" placeholder="Иванова Анна Петровна" className="mt-1 border-ytime-brand_secondary focus:border-ytime-brand_primary focus:ring-ytime-brand_primary" />
            </div>
            <div>
              <Label htmlFor="phone" className="text-sm font-medium text-ytime-brand_text_dark">Номер телефона</Label>
              <Input id="phone" type="tel" placeholder="+7 (9XX) XXX-XX-XX" className="mt-1 border-ytime-brand_secondary focus:border-ytime-brand_primary focus:ring-ytime-brand_primary" />
            </div>
            <div>
              <Label htmlFor="email" className="text-sm font-medium text-ytime-brand_text_dark">Email (необязательно)</Label>
              <Input id="email" type="email" placeholder="example@mail.com" className="mt-1 border-ytime-brand_secondary focus:border-ytime-brand_primary focus:ring-ytime-brand_primary" />
            </div>
          </div>
        </CardContent>
        <CardFooter>
          {/* In a real app, this would submit the form */}
          <Link to={`/map-services/booking-confirmation?serviceName=${encodeURIComponent(serviceName)}&clinicName=${encodeURIComponent(clinicName)}`} className="w-full">
            <Button className="w-full bg-ytime-brand_accent hover:bg-opacity-80 text-white text-lg py-3 shadow-md flex items-center justify-center">
              <CheckCircle className="w-5 h-5 mr-2" /> Подтвердить запись
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  );
}

// Mock data for service detail link, replace with actual logic if available
const MOCK_SERVICE_DETAIL = {
  id: "1", // Example ID
};

