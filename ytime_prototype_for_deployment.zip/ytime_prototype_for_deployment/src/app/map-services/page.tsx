import { Link } from "react-router-dom"; // Replaced next/link
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from "@/components/ui/card"; // Added CardFooter and CardDescription
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Filter, Star, Shield } from "lucide-react";

export default function MapServicesPage() {
  return (
    <div className="container mx-auto p-4">
      <header className="mb-8">
        <h1 className="text-3xl sm:text-4xl font-bold text-center text-ytime-brand_primary">Интерактивная карта</h1>
        <p className="text-center text-ytime-brand_text_dark mt-2">Найдите лучшие клиники, лаборатории, фитнес-центры и доставку еды рядом с вами.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Filters Panel */}
        <div className="md:col-span-1 bg-white p-6 rounded-xl shadow-lg">
          <h2 className="text-xl font-semibold mb-4 text-ytime-brand_primary flex items-center">
            <Filter className="w-5 h-5 mr-2 text-ytime-brand_accent" /> Фильтры
          </h2>
          <div className="space-y-4">
            <div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input type="search" placeholder="Поиск по названию..." className="pl-10" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-ytime-brand_text_dark">Тип сервиса</label>
              <div className="mt-2 space-y-2">
                {["Клиники", "Лаборатории", "Фитнес-центры", "Доставка еды"].map((service, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <Checkbox id={`filter-${index}`} className="border-ytime-brand_secondary data-[state=checked]:bg-ytime-brand_accent data-[state=checked]:text-white"/>
                    <label htmlFor={`filter-${index}`} className="text-sm text-ytime-brand_text_dark">{service}</label>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-ytime-brand_text_dark flex items-center">
                <Star className="w-4 h-4 mr-1 text-ytime-brand_accent" /> Рейтинг
              </label>
              <div className="mt-1 text-sm text-gray-500">[Компонент выбора рейтинга]</div>
            </div>
            <div>
              <label htmlFor="insurance-plan" className="text-sm font-medium text-ytime-brand_text_dark flex items-center">
                <Shield className="w-4 h-4 mr-1 text-ytime-brand_accent" /> Страховой план
              </label>
              <Select>
                <SelectTrigger id="insurance-plan" className="mt-1 border-ytime-brand_secondary focus:border-ytime-brand_primary focus:ring-ytime-brand_primary">
                  <SelectValue placeholder="Выберите страховой план" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="dms-alpha">ДМС "АльфаСтрахование"</SelectItem>
                  <SelectItem value="dms-renaissance">ДМС "Ренессанс Страхование"</SelectItem>
                  <SelectItem value="oms-123">ОМС (Городская поликлиника №123)</SelectItem>
                  <SelectItem value="no-insurance">Без страховки / Платные услуги</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2 pt-2">
              <Checkbox id="filter-online-booking" className="border-ytime-brand_secondary data-[state=checked]:bg-ytime-brand_accent data-[state=checked]:text-white"/>
              <label htmlFor="filter-online-booking" className="text-sm text-ytime-brand_text_dark">Только с онлайн-записью</label>
            </div>
            <div className="flex flex-col space-y-2 mt-4">
              <Button className="w-full bg-ytime-brand_accent hover:bg-opacity-80 text-white">Применить фильтры</Button>
              <Button variant="outline" className="w-full border-ytime-brand_secondary text-ytime-brand_secondary hover:bg-ytime-light_blue hover:text-ytime-brand_primary">Сбросить все</Button>
            </div>
          </div>
        </div>

        {/* Map and Results Area */}
        <div className="md:col-span-3">
          <div className="bg-ytime-light_blue h-96 rounded-xl mb-6 flex items-center justify-center text-ytime-brand_primary font-semibold shadow-inner">
            [Интерактивная карта Placeholder]
          </div>

          <h2 className="text-xl font-semibold mb-4 text-ytime-brand_primary">Результаты поиска</h2>
          <div className="space-y-4">
            {/* Example Service Card 1 */}
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 border-ytime-brand_background">
              <CardHeader>
                <CardTitle className="text-ytime-brand_primary">Клиника "Будь Здоров!"</CardTitle>
                <CardDescription className="text-ytime-brand_text_dark">Медицинский центр</CardDescription>
              </CardHeader>
              <CardContent className="text-ytime-brand_text_dark">
                <p>Рейтинг: 4.8 (150 отзывов)</p>
                <p>1.2 км от вас</p>
                <p className="mt-2 text-sm">Краткое описание сервиса, основные направления, преимущества.</p>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Link to="/map-services/service-detail?id=1"> {/* Replaced next/link */}
                  <Button className="bg-ytime-brand_primary hover:bg-opacity-80 text-white">Подробнее</Button>
                </Link>
              </CardFooter>
            </Card>
            {/* Example Service Card 2 */}
             <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 border-ytime-brand_background">
              <CardHeader>
                <CardTitle className="text-ytime-brand_primary">Фитнес-клуб "Энергия"</CardTitle>
                <CardDescription className="text-ytime-brand_text_dark">Фитнес-центр</CardDescription>
              </CardHeader>
              <CardContent className="text-ytime-brand_text_dark">
                <p>Рейтинг: 4.5 (88 отзывов)</p>
                <p>0.8 км от вас</p>
                <p className="mt-2 text-sm">Современный фитнес-клуб с бассейном и групповыми занятиями.</p>
              </CardContent>
              <CardFooter className="flex justify-end">
                 <Link to="/map-services/service-detail?id=2"> {/* Replaced next/link */}
                  <Button className="bg-ytime-brand_primary hover:bg-opacity-80 text-white">Подробнее</Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

