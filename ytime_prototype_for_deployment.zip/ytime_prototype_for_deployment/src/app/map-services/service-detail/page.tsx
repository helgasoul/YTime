import { Link } from "react-router-dom"; // Removed useSearchParams from import
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"; // Removed CardFooter and CardDescription from import
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, MapPin, Phone, Clock, Star, Edit3, Send } from "lucide-react"; // Removed ImageIcon from import

// Mock data - in a real app, this would come from an API based on query.id
const MOCK_SERVICE_DETAIL = {
  id: "1",
  name: "Клиника \"Здоровье Семьи\"",
  address: "г. Москва, ул. Ленина, д. 15, корп. 2",
  phone: "+7 (495) 123-45-67",
  hours: "Пн-Пт: 08:00 - 20:00, Сб: 09:00 - 17:00, Вс: выходной",
  ratingText: "Рейтинг: 4.7 (на основе 215 отзывов)",
  overviewText: "Клиника \"Здоровье Семьи\" — это современный многопрофильный медицинский центр, предлагающий широкий спектр услуг для всей семьи. Мы используем передовое оборудование и индивидуальный подход к каждому пациенту. Наша цель – ваше здоровье и благополучие.",
  photos: ["/placeholder-clinic-1.jpg", "/placeholder-clinic-2.jpg", "/placeholder-clinic-3.jpg"], // Placeholder image paths
  services: [
    { name: "Консультация терапевта первичная", price: "2500 руб." },
    { name: "УЗИ органов брюшной полости", price: "3200 руб." },
    { name: "Общий анализ крови (развернутый)", price: "1500 руб." },
  ],
  reviews: [
    { reviewerName: "Анна Иванова", date: "10.05.2025", reviewText: "Очень хорошая клиника, вежливый персонал, квалифицированные врачи. Рекомендую!", rating: 5 },
    { reviewerName: "Сергей Петров", date: "05.05.2025", reviewText: "Делал УЗИ, все прошло быстро и профессионально. Спасибо доктору Смирнову!", rating: 4 },
  ],
  specialists: [
    { photo: "/placeholder-doctor-1.jpg", name: "Сидорова Елена Васильевна", title: "Врач-терапевт, высшая категория, стаж 15 лет" },
    { photo: "/placeholder-doctor-2.jpg", name: "Кузнецов Андрей Викторович", title: "Врач-офтальмолог, к.м.н., стаж 12 лет" },
  ],
  minimapPlaceholder: "[Мини-карта с местоположением клиники]"
};

export default function ServiceDetailPage() {
  // const [searchParams] = useSearchParams(); // Removed unused variable searchParams
  // const serviceId = searchParams.get("id"); // Removed unused variable serviceId
  // In a real app, use serviceId to fetch actual data. For now, we use MOCK_SERVICE_DETAIL if id matches or just MOCK_SERVICE_DETAIL.
  const service = MOCK_SERVICE_DETAIL; // Simplified for mock data

  return (
    <div className="container mx-auto p-4">
      <header className="mb-6">
        <Link to="/map-services"> 
          <Button variant="outline" className="mb-4 border-ytime-brand_secondary text-ytime-brand_secondary hover:bg-ytime-light_blue hover:text-ytime-brand_primary">
            <ArrowLeft className="w-4 h-4 mr-2" /> Назад к карте
          </Button>
        </Link>
        <h1 className="text-3xl sm:text-4xl font-bold text-ytime-brand_primary">{service.name}</h1>
        <div className="text-sm text-ytime-brand_text_dark mt-2 space-y-1">
            <p className="flex items-center"><MapPin className="w-4 h-4 mr-2 text-ytime-brand_accent" /> {service.address}</p>
            <p className="flex items-center"><Phone className="w-4 h-4 mr-2 text-ytime-brand_accent" /> {service.phone}</p>
            <p className="flex items-center"><Clock className="w-4 h-4 mr-2 text-ytime-brand_accent" /> {service.hours}</p>
        </div>
        <p className="text-sm font-semibold mt-2 text-ytime-brand_primary flex items-center">
            <Star className="w-4 h-4 mr-1 text-yellow-400" /> {service.ratingText}
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Tabs defaultValue="overview" className="bg-white p-1 rounded-xl shadow-lg">
            <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 mb-4 bg-ytime-light_blue rounded-lg">
              <TabsTrigger value="overview" className="data-[state=active]:bg-ytime-brand_accent data-[state=active]:text-white">Обзор</TabsTrigger>
              <TabsTrigger value="services" className="data-[state=active]:bg-ytime-brand_accent data-[state=active]:text-white">Услуги</TabsTrigger>
              <TabsTrigger value="reviews" className="data-[state=active]:bg-ytime-brand_accent data-[state=active]:text-white">Отзывы</TabsTrigger>
              <TabsTrigger value="specialists" className="data-[state=active]:bg-ytime-brand_accent data-[state=active]:text-white">Специалисты</TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              <Card className="border-none shadow-none">
                <CardHeader>
                  <CardTitle className="text-ytime-brand_primary">Обзор клиники</CardTitle>
                </CardHeader>
                <CardContent className="text-ytime-brand_text_dark">
                  <p className="mb-4 text-base leading-relaxed">{service.overviewText}</p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {service.photos.map((photoUrl, index) => ( 
                      <div key={index} className="bg-ytime-light_blue h-40 rounded-lg flex items-center justify-center text-ytime-brand_secondary text-sm shadow-inner">
                        <img src={photoUrl} alt={`Clinic photo ${index + 1}`} className="w-full h-full object-cover rounded-lg" onError={(e) => (e.currentTarget.style.display = "none")} />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="services">
              <Card className="border-none shadow-none">
                <CardHeader>
                  <CardTitle className="text-ytime-brand_primary">Услуги и цены</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {service.services.map((item, index) => (
                    <div key={index} className="flex justify-between items-center p-4 bg-ytime-light_pink rounded-lg shadow-sm">
                      <div>
                        <p className="font-medium text-ytime-brand_primary">{item.name}</p>
                        <p className="text-sm text-ytime-brand_accent font-semibold">{item.price}</p>
                      </div>
                      <Link to={`/map-services/booking?serviceName=${encodeURIComponent(item.name)}&clinicName=${encodeURIComponent(service.name)}`}> 
                        <Button size="sm" className="bg-ytime-brand_accent hover:bg-opacity-80 text-white">Записаться</Button>
                      </Link>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reviews">
              <Card className="border-none shadow-none">
                <CardHeader>
                  <CardTitle className="text-ytime-brand_primary">Отзывы пациентов</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4 mb-6">
                    {service.reviews.map((review, index) => (
                      <div key={index} className="p-4 border border-ytime-brand_background rounded-lg bg-ytime-light_blue shadow-sm">
                        <p className="font-semibold text-ytime-brand_primary">{review.reviewerName} <span className="text-xs text-gray-500">({review.date})</span></p>
                        <p className="text-sm text-yellow-500">{"★".repeat(review.rating)}{"☆".repeat(5 - review.rating)}</p>
                        <p className="mt-1 text-sm text-ytime-brand_text_dark">{review.reviewText}</p>
                      </div>
                    ))}
                  </div>
                  <form className="space-y-3 border-t border-ytime-brand_background pt-6">
                    <h3 className="text-lg font-semibold text-ytime-brand_primary">Оставить отзыв</h3>
                    <div>
                      <label htmlFor="reviewerName" className="text-sm font-medium text-ytime-brand_text_dark">Ваше имя</label>
                      <Input id="reviewerName" placeholder="Ваше имя" className="mt-1 border-ytime-brand_secondary focus:border-ytime-brand_primary focus:ring-ytime-brand_primary" />
                    </div>
                    <div>
                      <label htmlFor="reviewText" className="text-sm font-medium text-ytime-brand_text_dark">Ваш отзыв</label>
                      <Textarea id="reviewText" placeholder="Напишите ваш отзыв здесь..." className="mt-1 border-ytime-brand_secondary focus:border-ytime-brand_primary focus:ring-ytime-brand_primary" />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-ytime-brand_text_dark">Оценка:</label>
                      <div className="mt-1 text-sm text-gray-500">[Компонент выбора оценки звездами]</div>
                    </div>
                    <Button type="submit" className="bg-ytime-brand_accent hover:bg-opacity-80 text-white flex items-center">
                      <Send className="w-4 h-4 mr-2" /> Оставить отзыв
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="specialists">
              <Card className="border-none shadow-none">
                <CardHeader>
                  <CardTitle className="text-ytime-brand_primary">Наши специалисты</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {service.specialists.map((spec, index) => (
                    <div key={index} className="flex items-center space-x-4 p-4 bg-ytime-light_pink rounded-lg shadow-sm">
                      <div className="w-20 h-20 bg-ytime-lavender_blue rounded-full flex items-center justify-center text-ytime-brand_secondary text-sm shadow-inner overflow-hidden">
                        <img src={spec.photo} alt={`Specialist ${spec.name}`} className="w-full h-full object-cover" onError={(e) => (e.currentTarget.style.display = "none")} />
                      </div>
                      <div className="flex-grow">
                        <p className="font-semibold text-ytime-brand_primary">{spec.name}</p>
                        <p className="text-sm text-ytime-brand_text_dark">{spec.title}</p>
                      </div>
                      <Link to={`/map-services/booking?specialistName=${encodeURIComponent(spec.name)}&clinicName=${encodeURIComponent(service.name)}`} className="ml-auto"> 
                        <Button size="sm" className="bg-ytime-brand_accent hover:bg-opacity-80 text-white flex items-center">
                          <Edit3 className="w-3 h-3 mr-1.5" /> Записаться
                        </Button>
                      </Link>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="md:col-span-1 space-y-6">
          <Card className="shadow-lg bg-white">
            <CardHeader>
              <CardTitle className="text-ytime-brand_primary">Местоположение</CardTitle>
            </CardHeader>
            <CardContent className="h-56 bg-ytime-light_blue rounded-lg flex items-center justify-center text-ytime-brand_secondary font-semibold shadow-inner">
              {service.minimapPlaceholder}
            </CardContent>
          </Card>
          <Link to={`/map-services/booking?clinicName=${encodeURIComponent(service.name)}`} className="block"> 
            <Button className="w-full bg-ytime-brand_accent hover:bg-opacity-80 text-white text-lg py-3 shadow-md">Записаться онлайн</Button>
          </Link>
        </div>
      </div>
    </div>
  );
}

