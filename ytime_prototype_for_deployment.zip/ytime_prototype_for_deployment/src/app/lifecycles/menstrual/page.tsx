// import { useState } from "react"; // Will need to make this a client component for state

// Mock data for calendar days and symptoms
// In a real app, this would be dynamic and managed
const daysInMonth = Array.from({ length: 30 }, (_, i) => i + 1);
const currentMonthYear = "Май 2024"; // Example

// Helper to determine day type (for styling)
const getDayInfo = (day: number) => {
  if ([3, 4, 5, 6].includes(day)) return { type: "period", icon: "🩸" };
  if (day === 14) return { type: "ovulation", icon: "🥚" };
  if ([10, 18, 25].includes(day)) return { type: "symptom", icon: "📝" }; // Days with logged symptoms
  return { type: "normal" };
};

export default function MenstrualCyclePage() {
  // const [selectedDay, setSelectedDay] = useState(null); // For symptom logging modal
  // const [showSymptomModal, setShowSymptomModal] = useState(false);

  return (
    <div className="min-h-screen bg-brand-background">
      {/* Reusable Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <a href="/dashboard/" className="flex items-center space-x-2">
                <img src="/assets/logo.png" alt="YTime Logo" width={40} height={40} />
                {/* <span className="text-2xl font-bold text-brand-primary">YTime</span> */}
              </a>
            </div>
            <nav className="hidden md:flex space-x-1">
              <a href="/dashboard/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Главная</a>
              <a href="/lifecycles/" className="text-brand-secondary font-semibold px-3 py-2 rounded-md text-sm">Жизненные Циклы</a>
              <a href="/risks/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Мои Риски</a>
              <a href="/map-services/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Карта Сервисов</a>
              <a href="/education/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Образование</a>
              <a href="/mental-wellness/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Ментальное Благополучие</a>
              <a href="/community/" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Сообщество</a>
            </nav>
            <div className="flex items-center">
              <span className="text-sm text-brand-text-primary mr-4">Профиль</span>
              <a href="/" className="text-sm text-brand-secondary hover:text-brand-accent">Выйти</a>
            </div>
          </div>
        </div>
      </header>

      <main className="py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-semibold text-brand-text-primary">Мой Менструальный Цикл</h1>
            <button 
              // onClick={() => setShowSymptomModal(true)} 
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-brand-primary-text-on-color bg-brand-primary hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-primary transition-colors"
            >
              Добавить симптомы сегодня
            </button>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md mb-8">
            <div className="flex justify-between items-center mb-4">
              <button className="text-brand-primary hover:text-brand-accent">&lt; Пред.</button>
              <h2 className="text-xl font-semibold text-brand-secondary">{currentMonthYear}</h2>
              <button className="text-brand-primary hover:text-brand-accent">След. &gt;</button>
            </div>
            <div className="grid grid-cols-7 gap-1 text-center text-sm text-brand-text-secondary mb-2">
              {["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"].map(day => <div key={day}>{day}</div>)}
            </div>
            <div className="grid grid-cols-7 gap-1">
              {/* Placeholder for empty days at start of month */}
              {Array.from({length: 2}).map((_, i) => <div key={`empty-${i}`} className="border rounded-md p-2 h-20 bg-gray-50"></div>)}
              {daysInMonth.map(day => {
                const info = getDayInfo(day);
                let bgColor = "bg-white";
                if (info.type === "period") bgColor = "bg-red-100"; // Consider brand color for period
                if (info.type === "ovulation") bgColor = "bg-green-100"; // Consider brand color for ovulation
                return (
                  <div 
                    key={day} 
                    // onClick={() => { setSelectedDay(day); setShowSymptomModal(true); }}
                    className={`border rounded-md p-2 h-20 flex flex-col justify-between cursor-pointer hover:shadow-lg transition-shadow ${bgColor}`}>
                    <span className="font-medium text-brand-text-primary">{day}</span>
                    {info.icon && <span className="text-xl self-center">{info.icon}</span>}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold text-brand-secondary mb-3">Сводка и Прогнозы</h2>
            <p className="text-sm text-brand-text-secondary">Средняя длительность цикла: 28 дней (пример)</p>
            <p className="text-sm text-brand-text-secondary">Прогноз следующей менструации: 1 июня 2024 (пример)</p>
            <a href="#" className="text-sm text-brand-primary hover:underline mt-2 inline-block">Смотреть полную аналитику (скоро)</a>
          </div>
        </div>
      </main>

      {/* Symptom Logging Modal (Simplified) - would be a separate component */}
      {/* {showSymptomModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center">
          <div className="p-8 border w-full max-w-md shadow-lg rounded-md bg-white">
            <h3 className="text-xl font-semibold text-brand-secondary mb-4">Добавить симптомы за {selectedDay || "сегодня"}</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-brand-text-primary">Физические симптомы:</label>
                <input type="text" className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-secondary focus:border-brand-secondary" placeholder="Например, головная боль"/>
              </div>
              <div>
                <label className="block text-sm font-medium text-brand-text-primary">Настроение:</label>
                <input type="text" className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-secondary focus:border-brand-secondary" placeholder="Например, раздражительность"/>
              </div>
              <div className="flex justify-end space-x-2">
                <button onClick={() => setShowSymptomModal(false)} className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300">Отмена</button>
                <button onClick={() => { alert("Симптомы сохранены (демо)"); setShowSymptomModal(false); }} className="px-4 py-2 bg-brand-primary text-brand-primary-text-on-color rounded hover:bg-opacity-90">Сохранить</button>
              </div>
            </div>
          </div>
        </div>
      )} */}

      <footer className="bg-white border-t border-gray-200 mt-10">
        <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 text-center text-sm text-brand-text-secondary">
          <p>&copy; {new Date().getFullYear()} YTime. Все права защищены.</p>
           <p className="mt-1">
            <a href="/terms/" className="hover:text-brand-secondary">Условия использования</a> | <a href="/privacy/" className="hover:text-brand-secondary">Политика конфиденциальности</a>
          </p>
        </div>
      </footer>
    </div>
  );
}

// To make this page interactive with useState, add "use client"; at the top of the file.
// For now, modal logic is commented out to keep it a server component for simplicity in this step.

