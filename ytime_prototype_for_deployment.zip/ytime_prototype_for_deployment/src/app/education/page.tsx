import { Link } from "react-router-dom"; // Replaced next/link

const educationCategories = [
  {
    id: 'menstrual-cycle',
    title: 'Все о Менструальном Цикле',
    description: 'Понимание фаз, гормонов и распространенных проблем.',
    icon: '🩸',
    articles: [
      { id: 'mc-1', title: 'Фазы менструального цикла: подробное руководство', snippet: 'Узнайте, что происходит в вашем теле...' },
      { id: 'mc-2', title: 'Гормональный баланс и его влияние на самочувствие', snippet: 'Эстроген, прогестерон и другие...' },
    ]
  },
  {
    id: 'reproductive-health',
    title: 'Репродуктивное Здоровье и Планирование Семьи',
    description: 'Информация о фертильности, контрацепции и подготовке к беременности.',
    icon: '👶',
    articles: [
      { id: 'rh-1', title: 'Как отследить овуляцию: методы и советы', snippet: 'Повысьте свои шансы на зачатие...' },
    ]
  },
  {
    id: 'menopause-health',
    title: 'Здоровье в Период Менопаузы',
    description: 'Симптомы, управление и поддержание качества жизни.',
    icon: '🦋',
    articles: []
  },
  {
    id: 'preventive-care',
    title: 'Профилактика Заболеваний',
    description: 'Важность регулярных осмотров и здорового образа жизни.',
    icon: '🛡️',
    articles: []
  },
];

export default function EducationPage() {
  return (
    <div className="min-h-screen bg-brand-background">
      {/* Reusable Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Link to="/dashboard" className="flex items-center space-x-2"> {/* Replaced next/link */}
                <img src="/assets/logo.png" alt="YTime Logo" width={40} height={40} /> {/* Replaced next/image */}
                {/* <span className="text-2xl font-bold text-brand-primary">YTime</span> */}
              </Link>
            </div>
            <nav className="hidden md:flex space-x-1">
              <Link to="/dashboard" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Главная</Link>
              <Link to="/lifecycles" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Жизненные Циклы</Link>
              <Link to="/risks" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Мои Риски</Link>
              <Link to="/map-services" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Карта Сервисов</Link>
              <Link to="/education" className="text-brand-secondary font-semibold px-3 py-2 rounded-md text-sm">Образование</Link>
              <Link to="/mental-wellness" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Ментальное Благополучие</Link>
              <Link to="/community" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Сообщество</Link>
            </nav>
            <div className="flex items-center">
              <span className="text-sm text-brand-text-primary mr-4">Профиль</span>
              <Link to="/" className="text-sm text-brand-secondary hover:text-brand-accent">Выйти</Link>
            </div>
          </div>
        </div>
      </header>

      <main className="py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-semibold text-brand-text-primary mb-4">Библиотека Знаний YTime</h1>
          <p className="text-md text-brand-text-secondary mb-8">Найдите научно-обоснованную информацию по интересующим вас темам женского здоровья.</p>
          
          <div className="mb-8">
            <input 
              type="search" 
              placeholder="Поиск по библиотеке... (например, СПКЯ, питание при беременности)" 
              className="w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-brand-secondary focus:border-brand-secondary text-brand-text-primary"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {educationCategories.map(category => (
              <Link key={category.id} to={`/education/${category.id}`} className="block p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="flex items-center mb-3">
                  <span className="text-3xl mr-4">{category.icon}</span>
                  <h2 className="text-lg font-semibold text-brand-secondary">{category.title}</h2>
                </div>
                <p className="text-sm text-brand-text-secondary mb-3">{category.description}</p>
                <span className="text-sm text-brand-primary hover:underline">Перейти к материалам &rarr;</span>
              </Link>
            ))}
          </div>
        </div>
      </main>

      <footer className="bg-white border-t border-gray-200 mt-10">
        <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 text-center text-sm text-brand-text-secondary">
          <p>&copy; {new Date().getFullYear()} YTime. Все права защищены.</p>
           <p className="mt-1">
            <Link to="/terms" className="hover:text-brand-secondary">Условия использования</Link> | <Link to="/privacy" className="hover:text-brand-secondary">Политика конфиденциальности</Link>
          </p>
        </div>
      </footer>
    </div>
  );
}

