import { Link } from "react-router-dom"; // Replaced next/link

const mentalWellnessResources = [
  {
    id: 'screening',
    title: 'Пройти Скрининг Самочувствия',
    description: 'Оцените свое текущее эмоциональное состояние (не является диагнозом).',
    link: '/mental-wellness/screening',
    icon: '📝',
    buttonText: 'Начать скрининг'
  },
  {
    id: 'meditations',
    title: 'Управляемые Медитации',
    description: 'Коллекция аудио-медитаций для расслабления и снятия стресса.',
    link: '/mental-wellness/meditations', // Placeholder for actual resource list
    icon: '🧘‍♀️',
    buttonText: 'Слушать'
  },
  {
    id: 'breathing-exercises',
    title: 'Дыхательные Упражнения',
    description: 'Простые техники дыхания для успокоения и концентрации.',
    link: '/mental-wellness/breathing', // Placeholder
    icon: '🌬️',
    buttonText: 'Практиковать'
  },
  {
    id: 'stress-reduction',
    title: 'Техники Снижения Стресса',
    description: 'Статьи и советы по управлению стрессом в повседневной жизни.',
    link: '/education/stress-management', // Link to a relevant education category
    icon: '😌',
    buttonText: 'Читать'
  }
];

export default function MentalWellnessPage() {
  return (
    <div className="min-h-screen bg-brand-background">
      {/* Reusable Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Link to="/dashboard" className="flex items-center space-x-2"> {/* Replaced next/link */}
                <img src="/assets/logo.png" alt="YTime Logo" width={40} height={40} /> {/* Replaced next/image */}
                {/* <span className="text-2xl font-bold text-brand-primary">YTime</span> */}
              </Link>
            </div>
            <nav className="hidden md:flex space-x-1">
              <Link to="/dashboard" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Главная</Link>
              <Link to="/lifecycles" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Жизненные Циклы</Link>
              <Link to="/risks" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Мои Риски</Link>
              <Link to="/map-services" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Карта Сервисов</Link>
              <Link to="/education" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Образование</Link>
              <Link to="/mental-wellness" className="text-brand-secondary font-semibold px-3 py-2 rounded-md text-sm">Ментальное Благополучие</Link>
              <Link to="/community" className="text-brand-text-primary hover:text-brand-secondary px-3 py-2 rounded-md text-sm font-medium">Сообщество</Link>
            </nav>
            <div className="flex items-center">
              <span className="text-sm text-brand-text-primary mr-4">Профиль</span>
              <Link to="/" className="text-sm text-brand-secondary hover:text-brand-accent">Выйти</Link>
            </div>
          </div>
        </div>
      </header>

      <main className="py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-semibold text-brand-text-primary mb-4">Ваше Ментальное Благополучие</h1>
          <p className="text-md text-brand-text-secondary mb-8">Забота о своем эмоциональном состоянии так же важна, как и о физическом здоровье. Здесь вы найдете инструменты и ресурсы для поддержки.</p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {mentalWellnessResources.map(resource => (
              <div key={resource.id} className="bg-white p-6 rounded-lg shadow-md flex flex-col justify-between hover:shadow-lg transition-shadow">
                <div>
                  <div className="flex items-center mb-3">
                    <span className="text-3xl mr-4">{resource.icon}</span>
                    <h2 className="text-lg font-semibold text-brand-secondary">{resource.title}</h2>
                  </div>
                  <p className="text-sm text-brand-text-secondary mb-4">{resource.description}</p>
                </div>
                <Link to={resource.link} className="mt-auto w-full text-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-brand-primary-text-on-color bg-brand-primary hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-primary transition-colors">
                  {resource.buttonText}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </main>

      <footer className="bg-white border-t border-gray-200 mt-10">
        <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 text-center text-sm text-brand-text-secondary">
          <p>&copy; {new Date().getFullYear()} YTime. Все права защищены.</p>
           <p className="mt-1">
            <Link to="/terms" className="hover:text-brand-secondary">Условия использования</Link> | <Link to="/privacy" className="hover:text-brand-secondary">Политика конфиденциальности</Link>
          </p>
        </div>
      </footer>
    </div>
  );
}

