import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Layout from "./app/layout"; // Assuming layout.tsx is the main layout
import HomePage from "./app/page";
import QuestionnairePage from "./app/questionnaire/page";
import DashboardPage from "./app/dashboard/page";
import LifecyclesPage from "./app/lifecycles/page";
import MenstrualCyclePage from "./app/lifecycles/menstrual/page";
import RisksPage from "./app/risks/page";
import RecommendationsPage from "./app/recommendations/page";
import EducationPage from "./app/education/page";
import MentalWellnessPage from "./app/mental-wellness/page";
import CommunityPage from "./app/community/page";
import MapServicesPage from "./app/map-services/page";
import ServiceDetailPage from "./app/map-services/service-detail/page";
import BookingPage from "./app/map-services/booking/page";

// Import global styles if not already handled in main.tsx or layout.tsx
import "./app/globals.css";

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/questionnaire" element={<QuestionnairePage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/lifecycles" element={<LifecyclesPage />} />
          <Route path="/lifecycles/menstrual" element={<MenstrualCyclePage />} />
          <Route path="/risks" element={<RisksPage />} />
          <Route path="/recommendations" element={<RecommendationsPage />} />
          <Route path="/education" element={<EducationPage />} />
          <Route path="/mental-wellness" element={<MentalWellnessPage />} />
          <Route path="/community" element={<CommunityPage />} />
          <Route path="/map-services" element={<MapServicesPage />} />
          <Route path="/map-services/service-detail" element={<ServiceDetailPage />} />
          <Route path="/map-services/booking" element={<BookingPage />} />
          {/* Add a redirect for any unknown paths to the homepage or a 404 component */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;

