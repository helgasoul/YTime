import { NextRequest, NextResponse } from "next/server";

export function middleware(req: NextRequest) {
  const basicAuth = req.headers.get("authorization");
  const url = req.nextUrl;

  if (basicAuth) {
    const authValue = basicAuth.split(" ")[1];
    const [user, pwd] = atob(authValue).split(":");

    // Replace with your own credentials
    const validUser = process.env.BASIC_AUTH_USER || "helgasoul";
    const validPassword = process.env.BASIC_AUTH_PASSWORD || "Qwerty9876";

    if (user === validUser && pwd === validPassword) {
      return NextResponse.next();
    }
  }
  url.pathname = "/api/auth-challenge"; // An endpoint that will trigger the browser's auth dialog

  const response = NextResponse.rewrite(url);
  response.headers.set("WWW-Authenticate", 'Basic realm="Secure Area"');
  response.status = 401;
  return response;
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - logo.png (logo file in public)
     */
    '/((?!api|_next/static|_next/image|favicon.ico|logo.png).*)',
  ],
};
