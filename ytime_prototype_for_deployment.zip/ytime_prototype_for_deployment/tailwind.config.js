/** @type {import("tailwindcss").Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "#FFFFFF", // White background
        foreground: "#1f2937", // Dark gray for text
        primary: {
          DEFAULT: "#f9d3d8", // Dominant pink from logo
          foreground: "#1f2937", // Dark gray for text on primary
        },
        secondary: {
          DEFAULT: "#fad4d9", // Lighter pink variant
          foreground: "#1f2937", // Dark gray for text on secondary
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "#f9d3d8", // Dominant pink from logo
          foreground: "#1f2937", // Dark gray for text on accent
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        // Custom YTime Palette (reflecting new branding)
        ytime: {
          brand_primary: "#f9d3d8",
          brand_secondary: "#fad4d9",
          brand_accent: "#f9d3d8",
          brand_background: "#FFFFFF",
          brand_text_dark: "#1f2937",
          brand_text_light: "#FFFFFF", // For text on dark pink backgrounds if any
          // Original colors kept for reference or specific elements if needed
          background_pink_old: "#f8d2d7",
          blue_old: "#47b1eb",
          magenta_pink_old: "#eb75b4",
          light_blue_old: "#c0d6f3",
          light_pink_old: "#f59ac8",
          lavender_blue_old: "#a6b3e8",
        }
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}

